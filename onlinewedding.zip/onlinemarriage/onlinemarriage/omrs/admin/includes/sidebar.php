   <div class="am-sideleft">
      <ul class="nav am-sideleft-tab">
      <li style="width:300px">
          <a href="#mainMenu" class="nav-link active"><i class="icon ion-ios-home-outline tx-24"></i></a>
        </li>
      </ul>

      <div class="tab-content">
        <div id="mainMenu" class="tab-pane active">
          <ul class="nav am-sideleft-menu">
            <li class="nav-item">
              <a href="dashboard.php" class="nav-link">
                <i class="icon ion-ios-home-outline"></i>
                <span>Dashboard</span>
              </a>
            </li><!-- nav-item -->
            <li class="nav-item">
              <a href="" class="nav-link with-sub active show-sub">
                <i class="icon ion-ios-gear-outline"></i>
                <span>Application</span>
              </a>
              <ul class="nav-sub">
                <li class="nav-item"><a href="new-marriage-application.php" class="nav-link">New Application</a></li>
                <li class="nav-item"><a href="verified-marriage-application.php" class="nav-link active">Verified Application</a></li>
                <li class="nav-item"><a href="rejected-marriage-application.php" class="nav-link active">Rejected Application</a></li>
                <li class="nav-item"><a href="all-marriage-application.php" class="nav-link active">All Application</a></li>
                
              </ul>
            </li><!-- nav-item -->
        <li class="nav-item">
              <a href="between-dates-application-report.php" class="nav-link">
                <i class="icon ion-ios-folder-outline"></i>
                <span>Report</span>
              </a>
           
            </li>
         
            <li class="nav-item">
              <a href="search.php" class="nav-link">
                <i class="icon ion-search"></i>
                <span>Search</span>
              </a>
            </li><!-- nav-item -->
          </ul>
        </div><!-- #mainMenu -->

      </div><!-- tab-content -->
    </div><!-- am-sideleft -->